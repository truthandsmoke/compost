//
//  compostApp.swift
//  compost
//
//  Created by Matthew Assaf on 3/27/25.
//

import SwiftUI

@main
struct compostApp: App {
    var body: some Scene {
        WindowGroup {
            CompostTeaView()
        }
    }
}
