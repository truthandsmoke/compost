import Foundation

struct Ingredient: Identifiable, Codable {
    let id = UUID()
    let name: String
    var quantity: Double
    let unit: String
    let microbialProfile: MicrobialProfile
    let nutrientProfile: NutrientProfile
    let physicalProperties: PhysicalProperties
}

struct NutrientProfile: Codable {
    var nitrogen: Double  // N content
    var phosphorus: Double  // P content
    var potassium: Double  // K content
    var carbon: Double    // C content
    var calcium: Double   // Ca content
    var magnesium: Double // Mg content
    var sulfur: Double    // S content
    var traceElements: [String: Double] // Other trace elements
}

struct PhysicalProperties: Codable {
    var moistureContent: Double  // Percentage
    var particleSize: Double     // Average size in mm
    var density: Double         // g/cm³
    var surfaceArea: Double     // m²/g
    var porosity: Double        // Percentage
}

struct MicrobialProfile: Codable {
    var bacterialCount: Double  // Percentage of total microbial population
    var fungalCount: Double     // Percentage of total microbial population
    var viralCount: Double      // Percentage of total microbial population
    var decompositionRate: Double
    var specificSpecies: [MicrobialSpecies]
}

struct MicrobialSpecies: Codable, Identifiable {
    let id = UUID()
    let name: String
    let type: MicrobialType
    var population: Double      // Percentage within its type
    let function: String
    let optimalConditions: OptimalConditions
    let metabolicRate: Double
    let reproductionRate: Double
    let interactions: [SpeciesInteraction]
}

struct SpeciesInteraction: Codable {
    let targetSpecies: String
    let interactionType: InteractionType
    let strength: Double
}

enum MicrobialType: String, Codable {
    case bacteria
    case fungus
    case virus
    case protozoa
    case actinomycetes
}

struct OptimalConditions: Codable {
    var temperature: ClosedRange<Double>
    var pH: ClosedRange<Double>
    var oxygen: ClosedRange<Double>
    var moisture: ClosedRange<Double>
}

enum InteractionType: String, Codable {
    case mutualism
    case commensalism
    case parasitism
    case competition
    case neutral
}

struct BrewingState: Codable {
    var isBrewing: Bool
    var startTime: Date?
    var currentTime: Date?
    var temperature: Double
    var dissolvedOxygen: Double
    var pH: Double
    var microbialPopulation: MicrobialProfile
    var nutrientLevels: NutrientProfile
    var physicalState: PhysicalProperties
}

class CompostTeaSimulator: ObservableObject {
    @Published var ingredients: [Ingredient] = []
    @Published var brewingState = BrewingState(
        isBrewing: false,
        startTime: nil,
        currentTime: nil,
        temperature: 68.0,
        dissolvedOxygen: 6.0,
        pH: 6.5,
        microbialPopulation: MicrobialProfile(
            bacterialCount: 0,
            fungalCount: 0,
            viralCount: 0,
            decompositionRate: 0,
            specificSpecies: []
        ),
        nutrientLevels: NutrientProfile(
            nitrogen: 0,
            phosphorus: 0,
            potassium: 0,
            carbon: 0,
            calcium: 0,
            magnesium: 0,
            sulfur: 0,
            traceElements: [:]
        ),
        physicalState: PhysicalProperties(
            moistureContent: 0,
            particleSize: 0,
            density: 0,
            surfaceArea: 0,
            porosity: 0
        )
    )
    
    // Default ingredients with enhanced properties
    let defaultIngredients = [
        Ingredient(
            name: "Water",
            quantity: 5.0,
            unit: "gallons",
            microbialProfile: MicrobialProfile(
                bacterialCount: 0,
                fungalCount: 0,
                viralCount: 0,
                decompositionRate: 0,
                specificSpecies: []
            ),
            nutrientProfile: NutrientProfile(
                nitrogen: 0,
                phosphorus: 0,
                potassium: 0,
                carbon: 0,
                calcium: 0,
                magnesium: 0,
                sulfur: 0,
                traceElements: [:]
            ),
            physicalProperties: PhysicalProperties(
                moistureContent: 100,
                particleSize: 0,
                density: 1.0,
                surfaceArea: 0,
                porosity: 0
            )
        ),
        Ingredient(
            name: "Alfalfa",
            quantity: 1.0,
            unit: "pounds",
            microbialProfile: MicrobialProfile(
                bacterialCount: 0.8,
                fungalCount: 0.2,
                viralCount: 0.1,
                decompositionRate: 0.7,
                specificSpecies: [
                    MicrobialSpecies(
                        name: "Rhizobium leguminosarum",
                        type: .bacteria,
                        population: 0.4,
                        function: "Nitrogen fixation, auxin production, nodulation, and siderophore synthesis",
                        optimalConditions: OptimalConditions(
                            temperature: 20...30,
                            pH: 6.0...7.5,
                            oxygen: 5...8,
                            moisture: 60...80
                        ),
                        metabolicRate: 0.5,
                        reproductionRate: 0.3,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .mutualism,
                                strength: 0.8
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Trichoderma harzianum",
                                interactionType: .commensalism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Azospirillum brasilense",
                                interactionType: .mutualism,
                                strength: 0.7
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Nitrosomonas europaea",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Streptomyces griseus",
                                interactionType: .commensalism,
                                strength: 0.4
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Trichoderma harzianum",
                        type: .fungus,
                        population: 0.15,
                        function: "Pathogen suppression, cellulase production, mycoparasitism, and secondary metabolite synthesis",
                        optimalConditions: OptimalConditions(
                            temperature: 25...35,
                            pH: 5.5...7.0,
                            oxygen: 4...7,
                            moisture: 50...70
                        ),
                        metabolicRate: 0.2,
                        reproductionRate: 0.1,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .mutualism,
                                strength: 0.7
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Fucus vesiculosus",
                                interactionType: .competition,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Streptomyces griseus",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .commensalism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Rhizobium leguminosarum",
                                interactionType: .commensalism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Azospirillum brasilense",
                                interactionType: .mutualism,
                                strength: 0.5
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Azospirillum brasilense",
                        type: .bacteria,
                        population: 0.25,
                        function: "Nitrogen fixation, IAA production, ACC deaminase activity, and biofilm formation",
                        optimalConditions: OptimalConditions(
                            temperature: 25...35,
                            pH: 6.5...7.5,
                            oxygen: 5...7,
                            moisture: 55...75
                        ),
                        metabolicRate: 0.4,
                        reproductionRate: 0.25,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Rhizobium leguminosarum",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Laminaria digitata",
                                interactionType: .commensalism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Nitrosomonas europaea",
                                interactionType: .commensalism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .mutualism,
                                strength: 0.7
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Trichoderma harzianum",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .mutualism,
                                strength: 0.6
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Streptomyces griseus",
                        type: .actinomycetes,
                        population: 0.15,
                        function: "Antibiotic production, cellulose degradation, secondary metabolite synthesis, and chitinase activity",
                        optimalConditions: OptimalConditions(
                            temperature: 25...35,
                            pH: 6.5...7.5,
                            oxygen: 5...7,
                            moisture: 55...75
                        ),
                        metabolicRate: 0.3,
                        reproductionRate: 0.2,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Trichoderma harzianum",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .competition,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Nitrosomonas europaea",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Rhizobium leguminosarum",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Azospirillum brasilense",
                                interactionType: .mutualism,
                                strength: 0.5
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Nitrosomonas europaea",
                        type: .bacteria,
                        population: 0.1,
                        function: "Ammonia oxidation, nitrite production, hydroxylamine metabolism, and biofilm formation",
                        optimalConditions: OptimalConditions(
                            temperature: 20...30,
                            pH: 7.0...8.0,
                            oxygen: 6...8,
                            moisture: 60...80
                        ),
                        metabolicRate: 0.4,
                        reproductionRate: 0.25,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Rhizobium leguminosarum",
                                interactionType: .mutualism,
                                strength: 0.7
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Azospirillum brasilense",
                                interactionType: .commensalism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Streptomyces griseus",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Trichoderma harzianum",
                                interactionType: .commensalism,
                                strength: 0.4
                            )
                        ]
                    )
                ]
            ),
            nutrientProfile: NutrientProfile(
                nitrogen: 2.5,
                phosphorus: 0.5,
                potassium: 2.0,
                carbon: 40.0,
                calcium: 1.5,
                magnesium: 0.3,
                sulfur: 0.3,
                traceElements: ["Fe": 0.02, "Zn": 0.01, "Cu": 0.005]
            ),
            physicalProperties: PhysicalProperties(
                moistureContent: 10,
                particleSize: 2.0,
                density: 0.4,
                surfaceArea: 0.8,
                porosity: 60
            )
        ),
        Ingredient(
            name: "Diatomaceous Earth",
            quantity: 0.5,
            unit: "pounds",
            microbialProfile: MicrobialProfile(
                bacterialCount: 0.1,
                fungalCount: 0.1,
                viralCount: 0.05,
                decompositionRate: 0.2,
                specificSpecies: []
            ),
            nutrientProfile: NutrientProfile(
                nitrogen: 0.01,
                phosphorus: 0.01,
                potassium: 0.005,
                carbon: 0.05,
                calcium: 0.005,
                magnesium: 0.005,
                sulfur: 0.005,
                traceElements: ["Fe": 0.005, "Zn": 0.005]
            ),
            physicalProperties: PhysicalProperties(
                moistureContent: 0,
                particleSize: 0.5,
                density: 0.5,
                surfaceArea: 0.5,
                porosity: 0
            )
        ),
        Ingredient(
            name: "Molasses",
            quantity: 5.0,
            unit: "tablespoons",
            microbialProfile: MicrobialProfile(
                bacterialCount: 0.9,
                fungalCount: 0.1,
                viralCount: 0.2,
                decompositionRate: 0.8,
                specificSpecies: []
            ),
            nutrientProfile: NutrientProfile(
                nitrogen: 0.05,
                phosphorus: 0.01,
                potassium: 0.02,
                carbon: 0.8,
                calcium: 0.005,
                magnesium: 0.005,
                sulfur: 0.005,
                traceElements: ["Fe": 0.005, "Zn": 0.005]
            ),
            physicalProperties: PhysicalProperties(
                moistureContent: 0,
                particleSize: 0,
                density: 0.9,
                surfaceArea: 0,
                porosity: 0
            )
        ),
        Ingredient(
            name: "Coffee Grounds",
            quantity: 1.0,
            unit: "pounds",
            microbialProfile: MicrobialProfile(
                bacterialCount: 0.7,
                fungalCount: 0.3,
                viralCount: 0.15,
                decompositionRate: 0.6,
                specificSpecies: []
            ),
            nutrientProfile: NutrientProfile(
                nitrogen: 0.05,
                phosphorus: 0.02,
                potassium: 0.01,
                carbon: 0.4,
                calcium: 0.005,
                magnesium: 0.005,
                sulfur: 0.005,
                traceElements: ["Fe": 0.005, "Zn": 0.005]
            ),
            physicalProperties: PhysicalProperties(
                moistureContent: 0,
                particleSize: 0.5,
                density: 0.7,
                surfaceArea: 0.5,
                porosity: 0
            )
        ),
        Ingredient(
            name: "Earthworm Castings",
            quantity: 1.0,
            unit: "pounds",
            microbialProfile: MicrobialProfile(
                bacterialCount: 0.6,
                fungalCount: 0.4,
                viralCount: 0.1,
                decompositionRate: 0.5,
                specificSpecies: []
            ),
            nutrientProfile: NutrientProfile(
                nitrogen: 0.05,
                phosphorus: 0.02,
                potassium: 0.01,
                carbon: 0.3,
                calcium: 0.005,
                magnesium: 0.005,
                sulfur: 0.005,
                traceElements: ["Fe": 0.005, "Zn": 0.005]
            ),
            physicalProperties: PhysicalProperties(
                moistureContent: 0,
                particleSize: 0.5,
                density: 0.6,
                surfaceArea: 0.5,
                porosity: 0
            )
        ),
        Ingredient(
            name: "Kelp",
            quantity: 1.0,
            unit: "pounds",
            microbialProfile: MicrobialProfile(
                bacterialCount: 0.6,
                fungalCount: 0.3,
                viralCount: 0.1,
                decompositionRate: 0.6,
                specificSpecies: [
                    MicrobialSpecies(
                        name: "Laminaria digitata",
                        type: .bacteria,
                        population: 0.3,
                        function: "Alginic acid decomposition, fucoidan degradation, laminarin metabolism, and iodine sequestration",
                        optimalConditions: OptimalConditions(
                            temperature: 15...25,
                            pH: 6.5...7.5,
                            oxygen: 6...8,
                            moisture: 70...90
                        ),
                        metabolicRate: 0.4,
                        reproductionRate: 0.2,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Rhizobium leguminosarum",
                                interactionType: .mutualism,
                                strength: 0.7
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .commensalism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Fucus vesiculosus",
                                interactionType: .competition,
                                strength: 0.3
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Alteromonas macleodii",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Marinomonas mediterranea",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Ectocarpus siliculosus",
                                interactionType: .mutualism,
                                strength: 0.5
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Fucus vesiculosus",
                        type: .fungus,
                        population: 0.2,
                        function: "Polysaccharide breakdown, phlorotannin metabolism, alginate degradation, and antioxidant production",
                        optimalConditions: OptimalConditions(
                            temperature: 10...20,
                            pH: 6.0...7.0,
                            oxygen: 5...7,
                            moisture: 60...80
                        ),
                        metabolicRate: 0.3,
                        reproductionRate: 0.15,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Trichoderma harzianum",
                                interactionType: .competition,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Marinomonas mediterranea",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Laminaria digitata",
                                interactionType: .competition,
                                strength: 0.3
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Alteromonas macleodii",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Ectocarpus siliculosus",
                                interactionType: .mutualism,
                                strength: 0.5
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Ectocarpus siliculosus",
                        type: .bacteria,
                        population: 0.1,
                        function: "Iodine metabolism, hormone production, fucoidan degradation, and antioxidant synthesis",
                        optimalConditions: OptimalConditions(
                            temperature: 12...22,
                            pH: 6.8...7.2,
                            oxygen: 6...8,
                            moisture: 65...85
                        ),
                        metabolicRate: 0.25,
                        reproductionRate: 0.12,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Laminaria digitata",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Azospirillum brasilense",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Marinomonas mediterranea",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Alteromonas macleodii",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Fucus vesiculosus",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .commensalism,
                                strength: 0.4
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Alteromonas macleodii",
                        type: .bacteria,
                        population: 0.15,
                        function: "Alginate degradation, sulfur metabolism, exopolysaccharide production, and biofilm formation",
                        optimalConditions: OptimalConditions(
                            temperature: 15...25,
                            pH: 6.8...7.2,
                            oxygen: 6...8,
                            moisture: 70...90
                        ),
                        metabolicRate: 0.35,
                        reproductionRate: 0.18,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Laminaria digitata",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Ectocarpus siliculosus",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Marinomonas mediterranea",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Fucus vesiculosus",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .commensalism,
                                strength: 0.4
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Marinomonas mediterranea",
                        type: .bacteria,
                        population: 0.1,
                        function: "Iodine metabolism, hormone synthesis, alginate degradation, and antioxidant production",
                        optimalConditions: OptimalConditions(
                            temperature: 12...22,
                            pH: 7.0...7.5,
                            oxygen: 6...8,
                            moisture: 65...85
                        ),
                        metabolicRate: 0.3,
                        reproductionRate: 0.15,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Ectocarpus siliculosus",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Fucus vesiculosus",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Alteromonas macleodii",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Laminaria digitata",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .commensalism,
                                strength: 0.4
                            )
                        ]
                    )
                ]
            ),
            nutrientProfile: NutrientProfile(
                nitrogen: 0.3,
                phosphorus: 0.1,
                potassium: 2.0,
                carbon: 35.0,
                calcium: 0.5,
                magnesium: 0.3,
                sulfur: 0.2,
                traceElements: [
                    "I": 0.05,
                    "Fe": 0.02,
                    "Zn": 0.01,
                    "Cu": 0.005,
                    "Mn": 0.01,
                    "B": 0.02
                ]
            ),
            physicalProperties: PhysicalProperties(
                moistureContent: 15,
                particleSize: 1.5,
                density: 0.3,
                surfaceArea: 1.2,
                porosity: 70
            )
        ),
        Ingredient(
            name: "Fish Emulsion",
            quantity: 5.0,
            unit: "tablespoons",
            microbialProfile: MicrobialProfile(
                bacterialCount: 0.9,
                fungalCount: 0.1,
                viralCount: 0.2,
                decompositionRate: 0.9,
                specificSpecies: [
                    MicrobialSpecies(
                        name: "Pseudomonas fluorescens",
                        type: .bacteria,
                        population: 0.5,
                        function: "Protein decomposition, siderophore production, antibiotic synthesis, and biofilm formation",
                        optimalConditions: OptimalConditions(
                            temperature: 20...30,
                            pH: 6.5...7.5,
                            oxygen: 5...7,
                            moisture: 50...70
                        ),
                        metabolicRate: 0.8,
                        reproductionRate: 0.6,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Laminaria digitata",
                                interactionType: .commensalism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Rhizobium leguminosarum",
                                interactionType: .mutualism,
                                strength: 0.8
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .competition,
                                strength: 0.3
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Nitrosomonas europaea",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Alteromonas macleodii",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Marinomonas mediterranea",
                                interactionType: .mutualism,
                                strength: 0.5
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Bacillus subtilis",
                        type: .bacteria,
                        population: 0.3,
                        function: "Nitrogen fixation, antibiotic production, biofilm formation, and chitinase activity",
                        optimalConditions: OptimalConditions(
                            temperature: 25...35,
                            pH: 7.0...8.0,
                            oxygen: 6...8,
                            moisture: 40...60
                        ),
                        metabolicRate: 0.6,
                        reproductionRate: 0.4,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Trichoderma harzianum",
                                interactionType: .mutualism,
                                strength: 0.7
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Fucus vesiculosus",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Streptomyces griseus",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .competition,
                                strength: 0.3
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Nitrosomonas europaea",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Azospirillum brasilense",
                                interactionType: .mutualism,
                                strength: 0.6
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Vibrio fischeri",
                        type: .bacteria,
                        population: 0.2,
                        function: "Protein degradation, bioluminescence, quorum sensing, and biofilm formation",
                        optimalConditions: OptimalConditions(
                            temperature: 15...25,
                            pH: 6.8...7.2,
                            oxygen: 5...7,
                            moisture: 45...65
                        ),
                        metabolicRate: 0.7,
                        reproductionRate: 0.5,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Ectocarpus siliculosus",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Shewanella putrefaciens",
                                interactionType: .mutualism,
                                strength: 0.7
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Photobacterium phosphoreum",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Alteromonas macleodii",
                                interactionType: .mutualism,
                                strength: 0.5
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Shewanella putrefaciens",
                        type: .bacteria,
                        population: 0.15,
                        function: "Protein degradation, sulfur reduction, extracellular electron transfer, and biofilm formation",
                        optimalConditions: OptimalConditions(
                            temperature: 15...25,
                            pH: 6.5...7.5,
                            oxygen: 5...7,
                            moisture: 45...65
                        ),
                        metabolicRate: 0.6,
                        reproductionRate: 0.4,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Vibrio fischeri",
                                interactionType: .mutualism,
                                strength: 0.7
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .competition,
                                strength: 0.3
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Photobacterium phosphoreum",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Alteromonas macleodii",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Marinomonas mediterranea",
                                interactionType: .commensalism,
                                strength: 0.4
                            )
                        ]
                    ),
                    MicrobialSpecies(
                        name: "Photobacterium phosphoreum",
                        type: .bacteria,
                        population: 0.1,
                        function: "Protein degradation, bioluminescence, quorum sensing, and biofilm formation",
                        optimalConditions: OptimalConditions(
                            temperature: 15...25,
                            pH: 6.8...7.2,
                            oxygen: 5...7,
                            moisture: 45...65
                        ),
                        metabolicRate: 0.5,
                        reproductionRate: 0.35,
                        interactions: [
                            SpeciesInteraction(
                                targetSpecies: "Vibrio fischeri",
                                interactionType: .mutualism,
                                strength: 0.6
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Shewanella putrefaciens",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Pseudomonas fluorescens",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Bacillus subtilis",
                                interactionType: .commensalism,
                                strength: 0.4
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Alteromonas macleodii",
                                interactionType: .mutualism,
                                strength: 0.5
                            ),
                            SpeciesInteraction(
                                targetSpecies: "Marinomonas mediterranea",
                                interactionType: .commensalism,
                                strength: 0.4
                            )
                        ]
                    )
                ]
            ),
            nutrientProfile: NutrientProfile(
                nitrogen: 5.0,
                phosphorus: 2.0,
                potassium: 1.0,
                carbon: 45.0,
                calcium: 0.1,
                magnesium: 0.1,
                sulfur: 0.5,
                traceElements: [
                    "Fe": 0.01,
                    "Zn": 0.005,
                    "Cu": 0.002,
                    "Mn": 0.005,
                    "B": 0.001
                ]
            ),
            physicalProperties: PhysicalProperties(
                moistureContent: 80,
                particleSize: 0.1,
                density: 1.1,
                surfaceArea: 0.8,
                porosity: 20
            )
        )
    ]
    
    init() {
        ingredients = defaultIngredients
    }
    
    func startBrewing() {
        brewingState.isBrewing = true
        brewingState.startTime = Date()
        brewingState.currentTime = Date()
        updateMicrobialPopulation()
        updateNutrientLevels()
        updatePhysicalState()
    }
    
    func stopBrewing() {
        brewingState.isBrewing = false
    }
    
    func updateMicrobialPopulation() {
        guard brewingState.isBrewing else { return }
        
        // Calculate total microbial counts based on ingredients
        var totalBacterial = 0.0
        var totalFungal = 0.0
        var totalViral = 0.0
        var totalDecomposition = 0.0
        var allSpecies: [MicrobialSpecies] = []
        
        for ingredient in ingredients {
            totalBacterial += ingredient.microbialProfile.bacterialCount * ingredient.quantity
            totalFungal += ingredient.microbialProfile.fungalCount * ingredient.quantity
            totalViral += ingredient.microbialProfile.viralCount * ingredient.quantity
            totalDecomposition += ingredient.microbialProfile.decompositionRate * ingredient.quantity
            
            // Add species with adjusted populations based on quantity
            for species in ingredient.microbialProfile.specificSpecies {
                var adjustedSpecies = species
                adjustedSpecies.population *= ingredient.quantity
                allSpecies.append(adjustedSpecies)
            }
        }
        
        // Apply species interactions
        for i in 0..<allSpecies.count {
            for interaction in allSpecies[i].interactions {
                if let targetIndex = allSpecies.firstIndex(where: { $0.name == interaction.targetSpecies }) {
                    switch interaction.interactionType {
                    case .mutualism:
                        allSpecies[i].population *= (1 + interaction.strength * 0.1)
                        allSpecies[targetIndex].population *= (1 + interaction.strength * 0.1)
                    case .commensalism:
                        allSpecies[i].population *= (1 + interaction.strength * 0.05)
                    case .parasitism:
                        allSpecies[i].population *= (1 + interaction.strength * 0.15)
                        allSpecies[targetIndex].population *= (1 - interaction.strength * 0.1)
                    case .competition:
                        allSpecies[i].population *= (1 - interaction.strength * 0.05)
                        allSpecies[targetIndex].population *= (1 - interaction.strength * 0.05)
                    case .neutral:
                        break
                    }
                }
            }
        }
        
        // Normalize values
        let total = totalBacterial + totalFungal + totalViral
        brewingState.microbialPopulation = MicrobialProfile(
            bacterialCount: totalBacterial / total,
            fungalCount: totalFungal / total,
            viralCount: totalViral / total,
            decompositionRate: totalDecomposition / Double(ingredients.count),
            specificSpecies: allSpecies
        )
    }
    
    func updateNutrientLevels() {
        var totalN = 0.0
        var totalP = 0.0
        var totalK = 0.0
        var totalC = 0.0
        var totalCa = 0.0
        var totalMg = 0.0
        var totalS = 0.0
        var totalTrace: [String: Double] = [:]
        
        // Calculate nutrient release rates based on microbial activity
        let microbialActivity = brewingState.microbialPopulation.decompositionRate
        
        for ingredient in ingredients {
            // Base nutrient content
            let baseN = ingredient.nutrientProfile.nitrogen * ingredient.quantity
            let baseP = ingredient.nutrientProfile.phosphorus * ingredient.quantity
            let baseK = ingredient.nutrientProfile.potassium * ingredient.quantity
            let baseC = ingredient.nutrientProfile.carbon * ingredient.quantity
            let baseCa = ingredient.nutrientProfile.calcium * ingredient.quantity
            let baseMg = ingredient.nutrientProfile.magnesium * ingredient.quantity
            let baseS = ingredient.nutrientProfile.sulfur * ingredient.quantity
            
            // Apply microbial decomposition effect
            totalN += baseN * (0.3 + 0.7 * microbialActivity)
            totalP += baseP * (0.2 + 0.8 * microbialActivity)
            totalK += baseK * (0.4 + 0.6 * microbialActivity)
            totalC += baseC * (0.5 + 0.5 * microbialActivity)
            totalCa += baseCa * (0.3 + 0.7 * microbialActivity)
            totalMg += baseMg * (0.3 + 0.7 * microbialActivity)
            totalS += baseS * (0.4 + 0.6 * microbialActivity)
            
            // Combine trace elements with microbial effect
            for (element, amount) in ingredient.nutrientProfile.traceElements {
                let baseAmount = amount * ingredient.quantity
                totalTrace[element, default: 0] += baseAmount * (0.3 + 0.7 * microbialActivity)
            }
        }
        
        // Calculate nutrient ratios and availability
        let cN = totalC / totalN
        let nP = totalN / totalP
        let kMg = totalK / totalMg
        
        // Adjust nutrient availability based on ratios
        if cN > 30 {
            totalN *= 0.8  // High C:N ratio reduces N availability
        }
        if nP > 10 {
            totalP *= 1.2  // High N:P ratio increases P availability
        }
        if kMg > 3 {
            totalMg *= 1.1  // High K:Mg ratio increases Mg availability
        }
        
        brewingState.nutrientLevels = NutrientProfile(
            nitrogen: totalN,
            phosphorus: totalP,
            potassium: totalK,
            carbon: totalC,
            calcium: totalCa,
            magnesium: totalMg,
            sulfur: totalS,
            traceElements: totalTrace
        )
    }
    
    func updatePhysicalState() {
        var totalMoisture = 0.0
        var totalParticleSize = 0.0
        var totalDensity = 0.0
        var totalSurfaceArea = 0.0
        var totalPorosity = 0.0
        var totalWeight = 0.0
        
        // Calculate microbial impact on physical properties
        let microbialActivity = brewingState.microbialPopulation.decompositionRate
        
        for ingredient in ingredients {
            // Base physical properties
            let baseMoisture = ingredient.physicalProperties.moistureContent * ingredient.quantity
            let baseParticleSize = ingredient.physicalProperties.particleSize * ingredient.quantity
            let baseDensity = ingredient.physicalProperties.density * ingredient.quantity
            let baseSurfaceArea = ingredient.physicalProperties.surfaceArea * ingredient.quantity
            let basePorosity = ingredient.physicalProperties.porosity * ingredient.quantity
            
            // Apply microbial decomposition effect
            totalMoisture += baseMoisture * (1 + 0.2 * microbialActivity)  // Microbial activity increases moisture
            totalParticleSize += baseParticleSize * (1 - 0.3 * microbialActivity)  // Decomposition reduces particle size
            totalDensity += baseDensity * (1 - 0.1 * microbialActivity)  // Decomposition reduces density
            totalSurfaceArea += baseSurfaceArea * (1 + 0.4 * microbialActivity)  // Decomposition increases surface area
            totalPorosity += basePorosity * (1 + 0.3 * microbialActivity)  // Decomposition increases porosity
            totalWeight += ingredient.quantity
        }
        
        // Calculate weighted averages
        let moisture = totalMoisture / totalWeight
        let particleSize = totalParticleSize / totalWeight
        let density = totalDensity / totalWeight
        let surfaceArea = totalSurfaceArea / totalWeight
        let porosity = totalPorosity / totalWeight
        
        // Apply environmental corrections
        let temperatureEffect = (brewingState.temperature - 20) / 20  // Temperature effect on physical properties
        let moistureEffect = (moisture - 50) / 50  // Moisture effect on physical properties
        
        brewingState.physicalState = PhysicalProperties(
            moistureContent: moisture * (1 + 0.1 * temperatureEffect),
            particleSize: particleSize * (1 - 0.1 * moistureEffect),
            density: density * (1 - 0.05 * temperatureEffect),
            surfaceArea: surfaceArea * (1 + 0.2 * moistureEffect),
            porosity: porosity * (1 + 0.15 * moistureEffect)
        )
    }
    
    func getDominantMicrobialType() -> String {
        let population = brewingState.microbialPopulation
        let maxCount = max(population.bacterialCount, population.fungalCount, population.viralCount)
        
        switch maxCount {
        case population.bacterialCount:
            return "Bacterial"
        case population.fungalCount:
            return "Fungal"
        case population.viralCount:
            return "Viral"
        default:
            return "Balanced"
        }
    }
    
    func getMicrobialDescription() -> String {
        let type = getDominantMicrobialType()
        let species = brewingState.microbialPopulation.specificSpecies
        
        var description = ""
        switch type {
        case "Bacterial":
            description = "Bacterial-dominated brew with high nitrogen-fixing potential and rapid decomposition rates.\n"
            let nitrogenFixers = species.filter { $0.type == .bacteria && $0.function.contains("Nitrogen") }
            if !nitrogenFixers.isEmpty {
                description += "Active nitrogen-fixing species: \(nitrogenFixers.map { $0.name }.joined(separator: ", "))"
            }
        case "Fungal":
            description = "Fungal-dominated brew ideal for woody material decomposition and long-term soil health.\n"
            let decomposers = species.filter { $0.type == .fungus && $0.function.contains("decomposition") }
            if !decomposers.isEmpty {
                description += "Active decomposer species: \(decomposers.map { $0.name }.joined(separator: ", "))"
            }
        case "Viral":
            description = "Viral-dominated brew with potential for disease suppression and microbial balance.\n"
            let suppressors = species.filter { $0.type == .virus && $0.function.contains("suppression") }
            if !suppressors.isEmpty {
                description += "Active disease suppression species: \(suppressors.map { $0.name }.joined(separator: ", "))"
            }
        default:
            description = "Balanced microbial population with diverse decomposition capabilities."
        }
        
        return description
    }
    
    func getNutrientAnalysis() -> String {
        let nutrients = brewingState.nutrientLevels
        return """
        NPK Ratio: \(String(format: "%.1f", nutrients.nitrogen)):\(String(format: "%.1f", nutrients.phosphorus)):\(String(format: "%.1f", nutrients.potassium))
        Carbon:Nitrogen Ratio: \(String(format: "%.1f", nutrients.carbon / nutrients.nitrogen))
        Calcium: \(String(format: "%.1f", nutrients.calcium))%
        Magnesium: \(String(format: "%.1f", nutrients.magnesium))%
        Sulfur: \(String(format: "%.1f", nutrients.sulfur))%
        """
    }
    
    func getPhysicalAnalysis() -> String {
        let physical = brewingState.physicalState
        return """
        Moisture Content: \(String(format: "%.1f", physical.moistureContent))%
        Average Particle Size: \(String(format: "%.1f", physical.particleSize))mm
        Bulk Density: \(String(format: "%.1f", physical.density))g/cm³
        Surface Area: \(String(format: "%.1f", physical.surfaceArea))m²/g
        Porosity: \(String(format: "%.1f", physical.porosity))%
        """
    }
    
    func addIngredient(name: String, quantity: Double, unit: String) {
        // Generate scientific properties based on ingredient type
        let (microbialProfile, nutrientProfile, physicalProperties) = generateScientificProperties(for: name)
        
        let newIngredient = Ingredient(
            name: name,
            quantity: quantity,
            unit: unit,
            microbialProfile: microbialProfile,
            nutrientProfile: nutrientProfile,
            physicalProperties: physicalProperties
        )
        
        ingredients.append(newIngredient)
    }
    
    private func generateScientificProperties(for ingredientName: String) -> (MicrobialProfile, NutrientProfile, PhysicalProperties) {
        // Get default microbial counts based on ingredient type
        let (bacterialCount, fungalCount, viralCount, decompositionRate) = getDefaultMicrobialCounts(for: ingredientName)
        
        // Generate species based on ingredient type
        let species = generateSpecies(for: ingredientName)
        
        // Get ChemML data for the ingredient
        let chemMLData = getChemMLData(for: ingredientName)
        
        // Create microbial profile with ChemML data
        let microbialProfile = MicrobialProfile(
            bacterialCount: bacterialCount,
            fungalCount: fungalCount,
            viralCount: viralCount,
            decompositionRate: decompositionRate,
            specificSpecies: species
        )
        
        // Create nutrient profile with ChemML data
        let nutrientProfile = NutrientProfile(
            nitrogen: chemMLData.nitrogen,
            phosphorus: chemMLData.phosphorus,
            potassium: chemMLData.potassium,
            carbon: chemMLData.carbon,
            calcium: chemMLData.calcium,
            magnesium: chemMLData.magnesium,
            sulfur: chemMLData.sulfur,
            traceElements: chemMLData.traceElements
        )
        
        // Create physical properties with ChemML data
        let physicalProperties = PhysicalProperties(
            moistureContent: chemMLData.moistureContent,
            particleSize: chemMLData.particleSize,
            density: chemMLData.density,
            surfaceArea: chemMLData.surfaceArea,
            porosity: chemMLData.porosity
        )
        
        return (microbialProfile, nutrientProfile, physicalProperties)
    }
    
    private func getChemMLData(for ingredientName: String) -> (nitrogen: Double, phosphorus: Double, potassium: Double, carbon: Double, calcium: Double, magnesium: Double, sulfur: Double, traceElements: [String: Double], moistureContent: Double, particleSize: Double, density: Double, surfaceArea: Double, porosity: Double) {
        // Convert ingredient name to lowercase for matching
        let name = ingredientName.lowercased()
        
        // Define ChemML data for common ingredients
        switch name {
        case let n where n.contains("compost"):
            return (0.02, 0.01, 0.01, 0.3, 0.005, 0.005, 0.005, ["Fe": 0.001, "Zn": 0.0005, "Cu": 0.0002], 0.6, 0.5, 0.6, 0.7, 0.4)
        case let n where n.contains("leaf"):
            return (0.02, 0.01, 0.01, 0.4, 0.01, 0.005, 0.005, ["Fe": 0.001, "Mn": 0.0005], 0.5, 0.6, 0.5, 0.8, 0.5)
        case let n where n.contains("wood"):
            return (0.01, 0.005, 0.005, 0.5, 0.01, 0.005, 0.005, ["Ca": 0.01, "Mg": 0.005], 0.4, 0.7, 0.4, 0.9, 0.6)
        case let n where n.contains("grass"):
            return (0.03, 0.01, 0.01, 0.35, 0.005, 0.005, 0.005, ["Fe": 0.001, "Zn": 0.0005], 0.7, 0.4, 0.5, 0.6, 0.4)
        case let n where n.contains("seaweed"):
            return (0.01, 0.01, 0.02, 0.25, 0.01, 0.01, 0.01, ["I": 0.001, "K": 0.02, "Na": 0.01], 0.8, 0.3, 0.3, 0.8, 0.7)
        case let n where n.contains("alfalfa"):
            return (0.03, 0.01, 0.02, 0.3, 0.01, 0.005, 0.005, ["Fe": 0.001, "Zn": 0.0005], 0.6, 0.4, 0.5, 0.7, 0.5)
        case let n where n.contains("coffee"):
            return (0.02, 0.01, 0.01, 0.4, 0.005, 0.005, 0.005, ["N": 0.02, "K": 0.01], 0.5, 0.5, 0.5, 0.6, 0.4)
        case let n where n.contains("worm"):
            return (0.03, 0.02, 0.01, 0.25, 0.01, 0.01, 0.005, ["Fe": 0.001, "Zn": 0.0005], 0.7, 0.3, 0.4, 0.8, 0.6)
        case let n where n.contains("diatom"):
            return (0.001, 0.001, 0.001, 0.1, 0.01, 0.005, 0.005, ["Si": 0.5, "Ca": 0.01], 0.1, 0.8, 0.2, 0.9, 0.8)
        case let n where n.contains("molasses"):
            return (0.01, 0.01, 0.01, 0.6, 0.005, 0.005, 0.005, ["Fe": 0.001, "K": 0.01], 0.8, 0.2, 0.3, 0.4, 0.3)
        case let n where n.contains("banana"):
            return (0.01, 0.01, 0.02, 0.3, 0.005, 0.005, 0.005, ["K": 0.02, "P": 0.01], 0.7, 0.3, 0.4, 0.6, 0.5)
        case let n where n.contains("potato"):
            return (0.02, 0.01, 0.02, 0.3, 0.005, 0.005, 0.005, ["K": 0.02, "P": 0.01], 0.7, 0.4, 0.5, 0.6, 0.5)
        case let n where n.contains("carrot"):
            return (0.01, 0.01, 0.02, 0.3, 0.01, 0.005, 0.005, ["K": 0.02, "Ca": 0.01], 0.7, 0.4, 0.5, 0.6, 0.5)
        case let n where n.contains("tomato"):
            return (0.02, 0.01, 0.02, 0.3, 0.005, 0.005, 0.005, ["K": 0.02, "P": 0.01], 0.7, 0.4, 0.5, 0.6, 0.5)
        case let n where n.contains("cucumber"):
            return (0.01, 0.01, 0.02, 0.3, 0.005, 0.005, 0.005, ["K": 0.02, "P": 0.01], 0.8, 0.3, 0.4, 0.7, 0.6)
        case let n where n.contains("lettuce"):
            return (0.02, 0.01, 0.02, 0.3, 0.01, 0.005, 0.005, ["K": 0.02, "Ca": 0.01], 0.8, 0.3, 0.4, 0.7, 0.6)
        default:
            // Default values for unknown ingredients based on general organic matter
            return (0.02, 0.01, 0.01, 0.35, 0.005, 0.005, 0.005, ["Fe": 0.001, "Zn": 0.0005], 0.6, 0.5, 0.5, 0.6, 0.5)
        }
    }
    
    private func getDefaultMicrobialCounts(for ingredientName: String) -> (Double, Double, Double, Double) {
        switch ingredientName.lowercased() {
        case let name where name.contains("compost"):
            return (0.6, 0.3, 0.1, 0.7)
        case let name where name.contains("leaf"):
            return (0.4, 0.5, 0.1, 0.6)
        case let name where name.contains("wood"):
            return (0.3, 0.6, 0.1, 0.5)
        case let name where name.contains("grass"):
            return (0.7, 0.2, 0.1, 0.7)
        case let name where name.contains("seaweed"):
            return (0.6, 0.3, 0.1, 0.6)
        case let name where name.contains("alfalfa"):
            return (0.8, 0.2, 0.1, 0.7)
        case let name where name.contains("coffee"):
            return (0.7, 0.3, 0.1, 0.6)
        case let name where name.contains("worm"):
            return (0.6, 0.4, 0.1, 0.5)
        case let name where name.contains("diatom"):
            return (0.1, 0.1, 0.05, 0.2)
        case let name where name.contains("molasses"):
            return (0.9, 0.1, 0.2, 0.8)
        case let name where name.contains("banana"):
            return (0.8, 0.15, 0.05, 0.7)
        case let name where name.contains("egg"):
            return (0.7, 0.2, 0.1, 0.6)
        case let name where name.contains("potato"):
            return (0.6, 0.3, 0.1, 0.5)
        case let name where name.contains("carrot"):
            return (0.5, 0.4, 0.1, 0.4)
        case let name where name.contains("tomato"):
            return (0.6, 0.3, 0.1, 0.5)
        case let name where name.contains("cucumber"):
            return (0.7, 0.2, 0.1, 0.6)
        case let name where name.contains("lettuce"):
            return (0.8, 0.15, 0.05, 0.7)
        default:
            return (0.5, 0.4, 0.1, 0.6)
        }
    }
    
    private func generateSpecies(for ingredientName: String) -> [MicrobialSpecies] {
        switch ingredientName.lowercased() {
        case let name where name.contains("compost"):
            return [
                MicrobialSpecies(
                    name: "Bacillus subtilis",
                    type: .bacteria,
                    population: 0.4,
                    function: "Nitrogen fixation and decomposition",
                    optimalConditions: OptimalConditions(
                        temperature: 25...35,
                        pH: 6.5...7.5,
                        oxygen: 5...7,
                        moisture: 50...70
                    ),
                    metabolicRate: 0.6,
                    reproductionRate: 0.4,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Trichoderma harzianum",
                            interactionType: .mutualism,
                            strength: 0.7
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Pseudomonas fluorescens",
                            interactionType: .mutualism,
                            strength: 0.6
                        )
                    ]
                ),
                MicrobialSpecies(
                    name: "Trichoderma harzianum",
                    type: .fungus,
                    population: 0.3,
                    function: "Cellulose degradation",
                    optimalConditions: OptimalConditions(
                        temperature: 25...35,
                        pH: 5.5...7.0,
                        oxygen: 4...7,
                        moisture: 50...70
                    ),
                    metabolicRate: 0.4,
                    reproductionRate: 0.2,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Bacillus subtilis",
                            interactionType: .mutualism,
                            strength: 0.7
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Aspergillus niger",
                            interactionType: .commensalism,
                            strength: 0.5
                        )
                    ]
                )
            ]
        case let name where name.contains("leaf"):
            return [
                MicrobialSpecies(
                    name: "Aspergillus niger",
                    type: .fungus,
                    population: 0.4,
                    function: "Cellulose and lignin degradation",
                    optimalConditions: OptimalConditions(
                        temperature: 25...35,
                        pH: 5.0...7.0,
                        oxygen: 4...7,
                        moisture: 40...60
                    ),
                    metabolicRate: 0.5,
                    reproductionRate: 0.3,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Trichoderma harzianum",
                            interactionType: .mutualism,
                            strength: 0.6
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Penicillium chrysogenum",
                            interactionType: .commensalism,
                            strength: 0.4
                        )
                    ]
                ),
                MicrobialSpecies(
                    name: "Penicillium chrysogenum",
                    type: .fungus,
                    population: 0.3,
                    function: "Organic matter decomposition",
                    optimalConditions: OptimalConditions(
                        temperature: 20...30,
                        pH: 5.5...7.0,
                        oxygen: 4...7,
                        moisture: 45...65
                    ),
                    metabolicRate: 0.4,
                    reproductionRate: 0.25,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Aspergillus niger",
                            interactionType: .commensalism,
                            strength: 0.4
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Bacillus subtilis",
                            interactionType: .mutualism,
                            strength: 0.5
                        )
                    ]
                )
            ]
        case let name where name.contains("wood"):
            return [
                MicrobialSpecies(
                    name: "Phanerochaete chrysosporium",
                    type: .fungus,
                    population: 0.5,
                    function: "Lignin degradation",
                    optimalConditions: OptimalConditions(
                        temperature: 25...35,
                        pH: 4.5...6.5,
                        oxygen: 5...7,
                        moisture: 45...65
                    ),
                    metabolicRate: 0.3,
                    reproductionRate: 0.2,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Trichoderma harzianum",
                            interactionType: .mutualism,
                            strength: 0.6
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Aspergillus niger",
                            interactionType: .commensalism,
                            strength: 0.4
                        )
                    ]
                ),
                MicrobialSpecies(
                    name: "Pleurotus ostreatus",
                    type: .fungus,
                    population: 0.3,
                    function: "Cellulose and hemicellulose degradation",
                    optimalConditions: OptimalConditions(
                        temperature: 20...30,
                        pH: 5.5...7.0,
                        oxygen: 5...7,
                        moisture: 50...70
                    ),
                    metabolicRate: 0.4,
                    reproductionRate: 0.25,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Phanerochaete chrysosporium",
                            interactionType: .mutualism,
                            strength: 0.5
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Bacillus subtilis",
                            interactionType: .commensalism,
                            strength: 0.4
                        )
                    ]
                )
            ]
        case let name where name.contains("grass"):
            return [
                MicrobialSpecies(
                    name: "Cellulomonas flavigena",
                    type: .bacteria,
                    population: 0.5,
                    function: "Cellulose degradation",
                    optimalConditions: OptimalConditions(
                        temperature: 25...35,
                        pH: 6.5...7.5,
                        oxygen: 5...7,
                        moisture: 50...70
                    ),
                    metabolicRate: 0.6,
                    reproductionRate: 0.4,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Bacillus subtilis",
                            interactionType: .mutualism,
                            strength: 0.7
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Trichoderma harzianum",
                            interactionType: .commensalism,
                            strength: 0.5
                        )
                    ]
                ),
                MicrobialSpecies(
                    name: "Streptomyces griseus",
                    type: .actinomycetes,
                    population: 0.3,
                    function: "Cellulose and hemicellulose degradation",
                    optimalConditions: OptimalConditions(
                        temperature: 25...35,
                        pH: 6.5...7.5,
                        oxygen: 5...7,
                        moisture: 50...70
                    ),
                    metabolicRate: 0.5,
                    reproductionRate: 0.3,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Cellulomonas flavigena",
                            interactionType: .mutualism,
                            strength: 0.6
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Bacillus subtilis",
                            interactionType: .commensalism,
                            strength: 0.4
                        )
                    ]
                )
            ]
        case let name where name.contains("seaweed"):
            return [
                MicrobialSpecies(
                    name: "Alteromonas macleodii",
                    type: .bacteria,
                    population: 0.4,
                    function: "Alginate degradation",
                    optimalConditions: OptimalConditions(
                        temperature: 15...25,
                        pH: 6.8...7.2,
                        oxygen: 6...8,
                        moisture: 70...90
                    ),
                    metabolicRate: 0.4,
                    reproductionRate: 0.2,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Bacillus subtilis",
                            interactionType: .mutualism,
                            strength: 0.6
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Pseudomonas fluorescens",
                            interactionType: .commensalism,
                            strength: 0.4
                        )
                    ]
                ),
                MicrobialSpecies(
                    name: "Marinomonas mediterranea",
                    type: .bacteria,
                    population: 0.3,
                    function: "Iodine metabolism",
                    optimalConditions: OptimalConditions(
                        temperature: 12...22,
                        pH: 7.0...7.5,
                        oxygen: 6...8,
                        moisture: 65...85
                    ),
                    metabolicRate: 0.3,
                    reproductionRate: 0.15,
                    interactions: [
                        SpeciesInteraction(
                            targetSpecies: "Alteromonas macleodii",
                            interactionType: .mutualism,
                            strength: 0.5
                        ),
                        SpeciesInteraction(
                            targetSpecies: "Bacillus subtilis",
                            interactionType: .commensalism,
                            strength: 0.4
                        )
                    ]
                )
            ]
        default:
            return []
        }
    }
} 
