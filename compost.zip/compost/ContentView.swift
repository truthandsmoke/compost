//
//  ContentView.swift
//  compost
//
//  Created by Matthew Assaf on 3/27/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        CompostTeaView()
    }
}

#Preview {
    ContentView()
}
