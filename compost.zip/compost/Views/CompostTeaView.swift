import SwiftUI
import Charts

struct CompostTeaView: View {
    @StateObject private var simulator = CompostTeaSimulator()
    @State private var showingAddIngredient = false
    @State private var newIngredientName = ""
    @State private var newIngredientQuantity = ""
    @State private var newIngredientUnit = ""
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Brewing Status
                    BrewingStatusView(simulator: simulator)
                    
                    // Ingredients List
                    IngredientsListView(simulator: simulator)
                    
                    // Brewing Controls
                    BrewingControlsView(simulator: simulator)
                    
                    // Microbial Analysis with Chart
                    MicrobialAnalysisView(simulator: simulator)
                    
                    // Nutrient Analysis with Chart
                    NutrientAnalysisView(simulator: simulator)
                    
                    // Physical Properties with Chart
                    PhysicalPropertiesView(simulator: simulator)
                }
                .padding()
            }
            .navigationTitle("Compost Tea Simulator")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingAddIngredient = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingAddIngredient) {
                AddIngredientView(simulator: simulator)
            }
        }
    }
}

struct BrewingStatusView: View {
    @ObservedObject var simulator: CompostTeaSimulator
    
    var body: some View {
        VStack {
            HStack {
                Circle()
                    .fill(simulator.brewingState.isBrewing ? Color.green : Color.red)
                    .frame(width: 20, height: 20)
                Text(simulator.brewingState.isBrewing ? "Brewing" : "Stopped")
                    .font(.headline)
            }
            
            if simulator.brewingState.isBrewing {
                Text("Temperature: \(String(format: "%.1f", simulator.brewingState.temperature))°F")
                Text("pH: \(String(format: "%.1f", simulator.brewingState.pH))")
                Text("Dissolved Oxygen: \(String(format: "%.1f", simulator.brewingState.dissolvedOxygen)) mg/L")
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

struct IngredientsListView: View {
    @ObservedObject var simulator: CompostTeaSimulator
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Ingredients")
                .font(.headline)
            
            ForEach(simulator.ingredients) { ingredient in
                IngredientRow(ingredient: ingredient)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

struct IngredientRow: View {
    let ingredient: Ingredient
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text(ingredient.name)
                    .font(.headline)
                Spacer()
                Text("\(String(format: "%.1f", ingredient.quantity)) \(ingredient.unit)")
            }
            
            if !ingredient.microbialProfile.specificSpecies.isEmpty {
                Text("Key Species:")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                ForEach(ingredient.microbialProfile.specificSpecies) { species in
                    VStack(alignment: .leading, spacing: 2) {
                        Text("• \(species.name) (\(species.type.rawValue))")
                            .font(.caption)
                        Text("  Function: \(species.function)")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        Text("  Metabolic Rate: \(String(format: "%.2f", species.metabolicRate))")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        Text("  Reproduction Rate: \(String(format: "%.2f", species.reproductionRate))")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            if !ingredient.nutrientProfile.traceElements.isEmpty {
                Text("Trace Elements:")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                ForEach(Array(ingredient.nutrientProfile.traceElements.keys.sorted()), id: \.self) { element in
                    if let amount = ingredient.nutrientProfile.traceElements[element] {
                        Text("• \(element): \(String(format: "%.3f", amount))%")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .padding(.vertical, 5)
    }
}

struct BrewingControlsView: View {
    @ObservedObject var simulator: CompostTeaSimulator
    
    var body: some View {
        HStack {
            Button(action: {
                if simulator.brewingState.isBrewing {
                    simulator.stopBrewing()
                } else {
                    simulator.startBrewing()
                }
            }) {
                Text(simulator.brewingState.isBrewing ? "Stop Brewing" : "Start Brewing")
                    .padding()
                    .background(simulator.brewingState.isBrewing ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

struct MicrobialAnalysisView: View {
    @ObservedObject var simulator: CompostTeaSimulator
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Microbial Analysis")
                .font(.headline)
            
            // Microbial Population Chart
            Chart {
                BarMark(
                    x: .value("Type", "Bacteria"),
                    y: .value("Population", simulator.brewingState.microbialPopulation.bacterialCount * 100)
                )
                .foregroundStyle(.blue)
                
                BarMark(
                    x: .value("Type", "Fungi"),
                    y: .value("Population", simulator.brewingState.microbialPopulation.fungalCount * 100)
                )
                .foregroundStyle(.green)
                
                BarMark(
                    x: .value("Type", "Viruses"),
                    y: .value("Population", simulator.brewingState.microbialPopulation.viralCount * 100)
                )
                .foregroundStyle(.red)
            }
            .frame(height: 200)
            
            // Species Distribution Chart
            if !simulator.brewingState.microbialPopulation.specificSpecies.isEmpty {
                Chart {
                    ForEach(simulator.brewingState.microbialPopulation.specificSpecies) { species in
                        BarMark(
                            x: .value("Species", species.name),
                            y: .value("Population", species.population * 100)
                        )
                        .foregroundStyle(by: .value("Type", species.type.rawValue))
                    }
                }
                .frame(height: 200)
            }
            
            Text(simulator.getMicrobialDescription())
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

struct NutrientAnalysisView: View {
    @ObservedObject var simulator: CompostTeaSimulator
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Nutrient Analysis")
                .font(.headline)
            
            // NPK Chart
            Chart {
                BarMark(
                    x: .value("Nutrient", "N"),
                    y: .value("Amount", simulator.brewingState.nutrientLevels.nitrogen)
                )
                .foregroundStyle(.blue)
                
                BarMark(
                    x: .value("Nutrient", "P"),
                    y: .value("Amount", simulator.brewingState.nutrientLevels.phosphorus)
                )
                .foregroundStyle(.green)
                
                BarMark(
                    x: .value("Nutrient", "K"),
                    y: .value("Amount", simulator.brewingState.nutrientLevels.potassium)
                )
                .foregroundStyle(.orange)
            }
            .frame(height: 200)
            
            // Secondary Nutrients Chart
            Chart {
                BarMark(
                    x: .value("Nutrient", "Ca"),
                    y: .value("Amount", simulator.brewingState.nutrientLevels.calcium)
                )
                .foregroundStyle(.purple)
                
                BarMark(
                    x: .value("Nutrient", "Mg"),
                    y: .value("Amount", simulator.brewingState.nutrientLevels.magnesium)
                )
                .foregroundStyle(.pink)
                
                BarMark(
                    x: .value("Nutrient", "S"),
                    y: .value("Amount", simulator.brewingState.nutrientLevels.sulfur)
                )
                .foregroundStyle(.yellow)
            }
            .frame(height: 200)
            
            Text(simulator.getNutrientAnalysis())
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

struct PhysicalPropertiesView: View {
    @ObservedObject var simulator: CompostTeaSimulator
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Physical Properties")
                .font(.headline)
            
            // Physical Properties Chart
            Chart {
                BarMark(
                    x: .value("Property", "Moisture"),
                    y: .value("Value", simulator.brewingState.physicalState.moistureContent)
                )
                .foregroundStyle(.blue)
                
                BarMark(
                    x: .value("Property", "Particle Size"),
                    y: .value("Value", simulator.brewingState.physicalState.particleSize)
                )
                .foregroundStyle(.green)
                
                BarMark(
                    x: .value("Property", "Density"),
                    y: .value("Value", simulator.brewingState.physicalState.density)
                )
                .foregroundStyle(.orange)
                
                BarMark(
                    x: .value("Property", "Surface Area"),
                    y: .value("Value", simulator.brewingState.physicalState.surfaceArea)
                )
                .foregroundStyle(.purple)
                
                BarMark(
                    x: .value("Property", "Porosity"),
                    y: .value("Value", simulator.brewingState.physicalState.porosity)
                )
                .foregroundStyle(.pink)
            }
            .frame(height: 200)
            
            Text(simulator.getPhysicalAnalysis())
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

struct AddIngredientView: View {
    @ObservedObject var simulator: CompostTeaSimulator
    @Environment(\.dismiss) var dismiss
    
    @State private var name = ""
    @State private var quantity = ""
    @State private var unit = ""
    
    var body: some View {
        NavigationView {
            Form {
                TextField("Ingredient Name", text: $name)
                TextField("Quantity", text: $quantity)
                    .keyboardType(.decimalPad)
                TextField("Unit", text: $unit)
            }
            .navigationTitle("Add Ingredient")
            .navigationBarItems(
                leading: Button("Cancel") { dismiss() },
                trailing: Button("Add") {
                    if let quantity = Double(quantity) {
                        let newIngredient = Ingredient(
                            name: name,
                            quantity: quantity,
                            unit: unit,
                            microbialProfile: MicrobialProfile(
                                bacterialCount: 0.5,
                                fungalCount: 0.3,
                                viralCount: 0.2,
                                decompositionRate: 0.5,
                                specificSpecies: []
                            ),
                            nutrientProfile: NutrientProfile(
                                nitrogen: 0.05,
                                phosphorus: 0.02,
                                potassium: 0.01,
                                carbon: 0.3,
                                calcium: 0.005,
                                magnesium: 0.005,
                                sulfur: 0.005,
                                traceElements: [:]
                            ),
                            physicalProperties: PhysicalProperties(
                                moistureContent: 0,
                                particleSize: 0.5,
                                density: 0.6,
                                surfaceArea: 0.5,
                                porosity: 0
                            )
                        )
                        simulator.ingredients.append(newIngredient)
                        dismiss()
                    }
                }
            )
        }
    }
}

#Preview {
    CompostTeaView()
} 